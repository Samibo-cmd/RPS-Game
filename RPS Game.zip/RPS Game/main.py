import random
from secrets import choice

print("Welcome to Rock, paper, Scissors!")
print("Have fun!")

Player_wins = 0
CPU_wins = 0
Ties = 0

choices = ["rock", "paper", "scissors"]

while True:
    CPU = random.choice(choices)
    user_input = input("Type Rock/Paper/Scissors or Q to quit: ").lower()
    print("Player", user_input + "-")
    if user_input == "q":
        break
    if user_input not in choices:
        print("Invalid option. Try again")
        continue
    
    print("CPU", CPU + "-")
    
    if user_input == CPU:
        print("It is a tie")
        Ties += 1
    
    elif user_input == "rock" and CPU == "scissors":
        print("You won!")
        Player_wins += 1
        
    elif user_input == "paper" and CPU == "rock":
        print("You won!")
        Player_wins += 1
        
    elif user_input == "scissors" and CPU == "rock":
        print("You won!")
        Player_wins += 1
        
    else:
        print("You lost!")
        CPU_wins += 1
        
print("You won", Player_wins, "times.")
print("Computer won", CPU_wins, "times.")
print("Ties", Ties, "times.")
print("Goodbye!")